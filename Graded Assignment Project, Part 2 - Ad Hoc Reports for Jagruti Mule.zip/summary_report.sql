-- Summary of Findings
-- Use this file to summarize your findings and make your recommendations where they have been requested.
-- Any recommendations should include the data to support why you are making that recommendation

-- 1. How many Toastmasters events are there using LetsMeet in New York, Chicago and San Francisco?





-- 2. Is LetsMeet membership leveling off?






-- 3. What five groups should marketing feature in their upcoming campaign?*
